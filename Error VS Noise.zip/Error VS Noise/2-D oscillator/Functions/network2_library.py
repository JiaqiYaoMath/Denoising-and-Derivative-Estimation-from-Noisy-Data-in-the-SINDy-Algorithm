#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 15 09:49:33 2022

@author: forootani
"""

import torch
import torch.nn as nn
from typing import List, Tuple
import torch.nn.init as init
import numpy as np
##########################################################################################################
class NNTanh(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_hidden[-1], n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            self.final.weight = torch.nn.Parameter(1 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
        architecture = [n_in] + n_hidden 
        for layer_i, layer_j in zip(architecture, architecture[1:]):
            network.append(nn.Linear(layer_i, layer_j))
            network.append(nn.Tanh())

        return nn.Sequential(*network)



##########################################################################################################
class NNSigmoid(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_hidden[-1], n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            self.final.weight = torch.nn.Parameter(1 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
        architecture = [n_in] + n_hidden 
        for layer_i, layer_j in zip(architecture, architecture[1:]):
            network.append(nn.Linear(layer_i, layer_j))
            network.append(nn.Sigmoid())

        return nn.Sequential(*network)
    
####################################################################################################    

class NNReLu(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_hidden[-1], n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            self.final.weight = torch.nn.Parameter(1 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
        architecture = [n_in] + n_hidden 
        for layer_i, layer_j in zip(architecture, architecture[1:]):
            network.append(nn.Linear(layer_i, layer_j))
            network.append(nn.ReLU())

        return nn.Sequential(*network)
    

#########################################################################################################


class ResidualBlock(nn.Module):
    """
    Single layer NN which by default it applies the Exponential Linear Unit (ELU) function element-wise.
    """

    def __init__(self, in_features, include_bias=True, zero_inits = False):
        super(ResidualBlock, self).__init__()
        self.linear = nn.Linear(in_features, in_features, bias = include_bias)
        self.activation = nn.ReLU()

        self.zero_inits = zero_inits
        if self.zero_inits:
            # Initialize weights to zero
            self.linear.weight = torch.nn.Parameter(0 * self.linear.weight.clone().detach())
            
    def forward(self, x):
        y = self.linear(x)
        y = self.activation(y)
        return (x+y)
    

class ResidualBlock_F(nn.Module):
    """
    Single layer NN which by default it applies the Exponential Linear Unit (ELU) function element-wise.
    """

    def __init__(self, in_features, out_features, include_bias=True, zero_inits = False):
        super(ResidualBlock_F, self).__init__()
        self.linear = nn.Linear(in_features, out_features, bias = include_bias)
        self.activation = nn.ReLU()
        self.n_broadcast = int(out_features/in_features)
        
        self.zero_inits = zero_inits
        if self.zero_inits:
            # Initialize weights to zero
            self.linear.weight = torch.nn.Parameter(0 * self.linear.weight.clone().detach())

    def forward(self, x):
        y = self.linear(x)
        y = self.activation(y)
        z = x.repeat_interleave(self.n_broadcast, dim=1)
        return (z+y)
    
    
class ResidualBlock_S(nn.Module):
    """
    Single layer NN which by default it applies the Exponential Linear Unit (ELU) function element-wise.
    """

    def __init__(self, in_features, hidden_features, include_bias=True, zero_inits = False):
        super(ResidualBlock_S, self).__init__()
        self.linear1 = nn.Linear(in_features, hidden_features, bias = include_bias)
        self.activation = nn.ReLU()
        self.linear2 = nn.Linear(hidden_features, in_features, bias = include_bias)

        self.zero_inits = zero_inits
        if self.zero_inits:
            # Initialize weights to zero
            self.linear1.weight = torch.nn.Parameter(0 * self.linear1.weight.clone().detach())
            
    def forward(self, x):
        y = self.linear1(x)
        y = self.activation(y)
        y = self.linear2(y)
        return (x+y)
    
################################################################################

class ResReLu(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_hidden[-1], n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            self.final.weight = torch.nn.Parameter(1 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(nn.Linear(n_in, n_hidden[0]))
        network.append(nn.ReLU())

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResidualBlock(layer_i))

        return nn.Sequential(*network)

##########################################################################################
class ResReLu_F(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_hidden[-1], n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            self.final.weight = torch.nn.Parameter(1 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResidualBlock_F(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResidualBlock(layer_i))

        return nn.Sequential(*network)

##############################################################################################

class ResReLu_S(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_in, n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            self.final.weight = torch.nn.Parameter(1 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResidualBlock_S(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResidualBlock_S(n_in, layer_i))

        return nn.Sequential(*network)

#############################################################################################

class ResReLu_SP(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, initial_guess, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_in, n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            with torch.no_grad():  # 在修改权重时禁用梯度计算
                self.final.weight.copy_(initial_guess.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResidualBlock_S(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResidualBlock_S(n_in, layer_i))

        return nn.Sequential(*network)


#############################################################################################

class ResSigmond_Block(nn.Module):
    """
    Single layer NN which by default it applies the Exponential Linear Unit (ELU) function element-wise.
    """

    def __init__(self, in_features, hidden_features, include_bias=False, zero_inits = False):
        super(ResSigmond_Block, self).__init__()
        self.in_features = in_features
        self.hidden_features = hidden_features
        
        self.linear1 = nn.Linear(in_features, hidden_features, bias = True)
        self.activation = nn.Sigmoid()
        self.linear2 = nn.Linear(hidden_features, in_features, bias = include_bias)

        self.zero_inits = zero_inits
        if self.zero_inits:
            # Initialize weights to zero
            self.linear1.weight = torch.nn.Parameter(0 * self.linear1.weight.clone().detach())

    #     # 使用标准正态分布初始化权重
    #     self._initialize_weights()
        
    # def _initialize_weights(self):
    #     # 对每一层的权重进行标准正态分布初始化
    #     init.normal_(self.linear1.weight, mean=0.0, std= np.sqrt(2/(self.in_features + self.hidden_features)) )  # 标准正态分布初始化
    #     init.normal_(self.linear2.weight, mean=0.0, std= np.sqrt(8/(3*self.in_features)))


            
    def forward(self, x):
        y = self.linear1(x)
        y = self.activation(y)
        y = self.linear2(y)
        return (x+y)
    

class ResSigmond_S(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_in, n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResSigmond_Block(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResSigmond_Block(n_in, layer_i))

        return nn.Sequential(*network)


#####################################################################################
class ResSigmond_SP(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, initial_guess, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_in, n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            with torch.no_grad():  # 在修改权重时禁用梯度计算
                self.final.weight.copy_(initial_guess.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResSigmond_Block(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResSigmond_Block(n_in, layer_i))

        return nn.Sequential(*network)


###############################################################################################

class ResTanh_Block(nn.Module):
    """
    Single layer NN which by default it applies the Exponential Linear Unit (ELU) function element-wise.
    """

    def __init__(self, in_features, hidden_features, include_bias=False, zero_inits = False):
        super(ResTanh_Block, self).__init__()
        self.in_features = in_features
        self.hidden_features = hidden_features
        
        self.linear1 = nn.Linear(in_features, hidden_features, bias = True)
        self.activation = nn.Tanh()
        self.linear2 = nn.Linear(hidden_features, in_features, bias = include_bias)

        self.zero_inits = zero_inits
        if self.zero_inits:
            # Initialize weights to zero
            self.linear1.weight = torch.nn.Parameter(0 * self.linear1.weight.clone().detach())

    #     # 使用标准正态分布初始化权重
    #     self._initialize_weights()
        
    # def _initialize_weights(self):
    #     # 对每一层的权重进行标准正态分布初始化
    #     init.normal_(self.linear1.weight, mean=0.0, std= np.sqrt(2/(self.in_features + self.hidden_features)) )  # 标准正态分布初始化
    #     init.normal_(self.linear2.weight, mean=0.0, std= np.sqrt(8/(3*self.in_features)))


            
    def forward(self, x):
        y = self.linear1(x)
        y = self.activation(y)
        y = self.linear2(y)
        return (x+y)
    

class ResTanh_SP(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, initial_guess, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_in, n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())
        else:
            # Xavier initialization
            with torch.no_grad():  # 在修改权重时禁用梯度计算
                self.final.weight.copy_(initial_guess.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResTanh_Block(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResTanh_Block(n_in, layer_i))

        return nn.Sequential(*network)

#########################################################################################

class ResELU_Block(nn.Module):
    """
    Single layer NN which by default it applies the Exponential Linear Unit (ELU) function element-wise.
    """

    def __init__(self, in_features, hidden_features, include_bias=False, zero_inits = False):
        super(ResELU_Block, self).__init__()
        self.in_features = in_features
        self.hidden_features = hidden_features
        
        self.linear1 = nn.Linear(in_features, hidden_features, bias = True)
        self.activation = nn.ELU()
        self.linear2 = nn.Linear(hidden_features, in_features, bias = include_bias)

        self.zero_inits = zero_inits
        if self.zero_inits:
            # Initialize weights to zero
            self.linear1.weight = torch.nn.Parameter(0 * self.linear1.weight.clone().detach())

    #     # 使用标准正态分布初始化权重
    #     self._initialize_weights()
        
    # def _initialize_weights(self):
    #     # 对每一层的权重进行标准正态分布初始化
    #     init.normal_(self.linear1.weight, mean=0.0, std= np.sqrt(2/(self.in_features + self.hidden_features)) )  # 标准正态分布初始化
    #     init.normal_(self.linear2.weight, mean=0.0, std= np.sqrt(8/(3*self.in_features)))


            
    def forward(self, x):
        y = self.linear1(x)
        y = self.activation(y)
        y = self.linear2(y)
        return (x+y)
    

class ResELU_S(nn.Module):
    def __init__(self, n_in: int, n_hidden: List[int], n_out: int, zero_inits = False ) -> None:
        """
        Discription:
        Constructing a NN with Tanh activation function
        Args:
            n_in: number of input features
            n_hidden: number of neurons in the hidden layes
            n_out: number of outputs
        """
        super().__init__()
        self.network = self.build_network(n_in, n_hidden)
        self.final =  nn.Linear(n_in, n_out, bias=False)
        self.zero_inits = zero_inits

        if self.zero_inits:
            # Initialize weights to zero
            self.final.weight = torch.nn.Parameter(0 * self.final.weight.clone().detach())


    def forward(self, input_data : torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.network(input_data.float())
        x = self.final(x)

        return x

    def build_network( self, n_in: int, n_hidden: List[int]) -> torch.nn.Sequential:

        network = []
    
        network.append(ResELU_Block(n_in, n_hidden[0]))

        architecture =  n_hidden 
        for layer_i in architecture:
            network.append(ResELU_Block(n_in, layer_i))

        return nn.Sequential(*network)

