""" Module to log performance metrics whilst training iNeuralSINDy """
import numpy as np
import torch
import sys, time


class Burnin_Logger1:
    def __call__( self,iteration,loss_values_NN,burnin_iterations):
        self.update_terminal(iteration, loss_values_NN, burnin_iterations)

    def update_terminal( self, iteration, loss_values_NN, burnin_iterations):
        """Prints and updates progress of training cycle in command line."""
        sys.stdout.write(
            f"\r Burn in Process 1: {iteration:>6} \
                loss_values_NN: {loss_values_NN[-1]:>8.2e} "
        )
        
        if (iteration == burnin_iterations -1):
            sys.stdout.write("\n")
            sys.stdout.write("=================")
            sys.stdout.write("\n")

            
        sys.stdout.flush()


class Burnin_Logger2:
    def __call__( self, iteration, loss_values, loss_values_fun, loss_values_der, burnin_iterations):
        self.update_terminal(iteration, loss_values, loss_values_fun, loss_values_der, burnin_iterations)

    def update_terminal( self, iteration, loss_values, loss_values_fun, loss_values_der, burnin_iterations):
        """Prints and updates progress of training cycle in command line."""
        sys.stdout.write(
            f"\r Burn in Process 2: {iteration:>6} \
                loss_values: {loss_values[-1]:>8.2e}\
                loss_values_fun: {loss_values_fun[-1]:8.2e}\
                loss_values_der: {loss_values_der[-1]:8.2e}"
        )
        
        if (iteration == burnin_iterations -1):
            sys.stdout.write("\n")
            sys.stdout.write("=================")
            sys.stdout.write("\n")

            
        sys.stdout.flush()
        
        

#############################################################################################

class Logger:

    def __call__(
        self,
        iteration,
        loss_values,
        loss_values_derivative,
        loss_values_RK4,
        weight,
        threshold_iterations,
        period_iteration
    ):


        self.update_terminal(
            iteration, loss_values_derivative, loss_values_RK4, loss_values
        )

        self.update_coefficients(
            weight,
            iteration,
            threshold_iterations,
            period_iteration
        )

        # self.update_tensorboard(iteration, running_loss,
        #                       loss_values_Coeff, loss_values_NN,
        #                       loss_values_RK4, estimated_coeffs_k,
        #                       write_iterations, threshold_iteration)


    def update_terminal(self, iteration, loss_values_derivative, loss_values_RK4, loss_values):
        """Prints and updates progress of training cycle in command line."""
        sys.stdout.write(
            f"\r{iteration:>6} running_loss: {loss_values[-1]:>8.2e} \
            loss_values_derivative: {loss_values_derivative[-1]:>8.2e} \
                loss_values_RK4: {loss_values_RK4[-1]:>8.2e} "
        )
        sys.stdout.flush()

    def update_coefficients(
        self,
        weight,
        iteration,
        threshold_iterations,
        period_iteration
    ):

        if iteration > threshold_iterations and iteration % period_iteration == 0:

            sys.stdout.write("\n")
            sys.stdout.write("=================")
            sys.stdout.write("\n")
            sys.stdout.write("=================")
            sys.stdout.write("\n")
            sys.stdout.write(
                f"\r{iteration>0}  Weight:  \
                    {weight}"
            )

            sys.stdout.write("\n")

            sys.stdout.flush()

    # def close(self, model):
    #     """Close the Tensorboard writer"""
    #     print("Algorithm converged. Writing model to disk.")
    #     self.writer.flush()  # flush remaining stuff to disk
    #     self.writer.close()  # close writer

    #     # Save model
    #     model_path = self.log_dir + "model.pt"
    #     torch.save(model.state_dict(), model_path)
