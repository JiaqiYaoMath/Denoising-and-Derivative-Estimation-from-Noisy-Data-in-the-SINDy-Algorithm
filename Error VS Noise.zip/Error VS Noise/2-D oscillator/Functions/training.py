import torch
from Functions.calculation import Derivative, Library, RK4, Numerical_Derivative, library_deriv
import torch.nn as nn
from Functions.logger import Logger, Burnin_Logger1, Burnin_Logger2
from Functions.data_set import train_test_derivative
import numpy as np

if torch.cuda.is_available():
    device = "cuda"
else:
    device = "cpu"


##########################################################################################
def pre_train(
    network1,
    optimizer1,
    train_dataloader,
    param_set,
    data_total
) -> None:

    burnin_iterations = param_set.burnin_iterations
    max_iterations = param_set.max_iterations
    period_iteration = param_set.period_iteration
    threshold_value = param_set.threshold_value
    RK_timestep = param_set.RK_timestep
    useRK = param_set.useRK
    useNN = param_set.useNN
    time_deriv_coef = param_set.time_deriv_coef

    ###############################################################
    
    network1 = network1.to(device)
    
    network1.train()
    print(f"Model set-up useRK: {useRK}, useNN: {useNN}!")

    loss_fn = nn.MSELoss()
    
    loss_values_NN = []

    burnin_logger1 = Burnin_Logger1()
    burnin_logger2 = Burnin_Logger2()
    
    ##############################################################################################
    for iteration in range(burnin_iterations):
        
        optimizer1.zero_grad()
        loss = torch.autograd.Variable( torch.tensor([0.0], requires_grad=True)).to(device)
        
        for i in range(len(train_dataloader)):
            for batch_idx, train_sample in enumerate(train_dataloader[i]):
                (data_train, target_train) = train_sample

                #######################################

                """loading the data to GPU """

                data_train = data_train.float().to(device)
                target_train = target_train.float().to(device)
                
                #######################################
                
                prediction =  network1(data_train)         
                loss += loss_fn(prediction,target_train)
        
        
        
        loss.backward()
        optimizer1.step()
        
        loss_values_NN.append(loss.item())
        ##########################################Loggering
        
        burnin_logger1(iteration,loss_values_NN,burnin_iterations)
    
    
    ##############################################prepare dataset
    optimizer1.zero_grad()
    
    network1 = network1.cpu()
    
    times = []
    targets = []
    deris = []

    for i in range(len(data_total)):

        datas = data_total[i]
        total_time, total_target = datas.giveback()
        
        with torch.no_grad():
            prediction = network1(total_time)
        
        deri = Numerical_Derivative(prediction, param_set)
        
        times.append(total_time)
        targets.append(total_target)
        deris.append(deri)


    train_dataloader1, test_dataloader1, data_total1 = train_test_derivative(times, targets, deris, param_set)
    ########################################################################
    optimizer1.zero_grad()
    network1 = network1.to(device)
    
    network1.train()

    loss_values = []
    loss_values_fun = []
    loss_values_der = []
    
    for iteration in range(burnin_iterations):
        
        optimizer1.zero_grad()
        loss_fun = torch.autograd.Variable( torch.tensor([0.0], requires_grad=True)).to(device)
        loss_der = torch.autograd.Variable( torch.tensor([0.0], requires_grad=True)).to(device)
        
        for i in range(len(train_dataloader1)):
            for batch_idx, train_sample in enumerate(train_dataloader1[i]):
                (data_train, target_train, derivative_train) = train_sample

                #######################################

                """loading the data to GPU """

                data_train = data_train.float().to(device)
                target_train = target_train.float().to(device)
                derivative_train = derivative_train.float().to(device)
                
                #######################################
                
                prediction =  network1(data_train)         
                loss_fun += loss_fn(prediction,target_train)
                
                
                X = data_train.clone().detach().requires_grad_(True)
                prediction = network1(X)
                
                for k in np.arange(prediction.shape[1]):
                    time_deriv = library_deriv(X, prediction[:,k : k + 1], time_deriv_coef )
                    
                    loss_der += loss_fn(time_deriv,derivative_train[:,k:k+1])/prediction.shape[1]

        
        loss = 1.0 * loss_fun + 1.0 * loss_der
        
        loss.backward()
        optimizer1.step()
        
        loss_values.append(loss.item())
        loss_values_fun.append(loss_fun.item())
        loss_values_der.append(loss_der.item())
        ##########################################Loggering
        
        burnin_logger2(iteration, loss_values, loss_values_fun, loss_values_der, burnin_iterations)
        
        
    return loss_values_NN, loss_values_fun, loss_values_der, network1


###########################################################################################
########################################################################################
#########################################################################################3



def train(
    network2,
    optimizer2,
    train_dataloader,
    param_set
) -> None:
    
    ################################################################
    threshold_iterations = param_set.threshold_iterations
    max_iterations = param_set.max_iterations
    period_iteration = param_set.period_iteration
    threshold_value = param_set.threshold_value
    RK_timestep = param_set.RK_timestep
    useRK = param_set.useRK
    useNN = param_set.useNN

    ###############################################################
    
    network2 = network2.to(device)
    
    network2.train()
    print(f"Model set-up useRK: {useRK}, useNN: {useNN}!")

    loss_fn = nn.MSELoss()
    
    
    loss_values = []
    loss_values_derivative = []
    loss_values_RK4 = []

    logger = Logger()
    
    ####################################################################################
    (data_train, target_train, prediction, LHS, fun_library) = train_dataloader[0].dataset.giveback()

    data_train = data_train.float().to(device)
    target_train = target_train.float().to(device)
    prediction = prediction.float().to(device)
    LHS = LHS.float().to(device)
    fun_library = fun_library.float().to(device)
        
        
    for iteration in range(max_iterations):

        optimizer2.zero_grad()
             
        RHS = network2(fun_library)
        loss_derivative = loss_fn(LHS,RHS)
        loss_RK4 = torch.tensor([0.0]).to(device)
        
        # RK4_pred = RK4( network2, target_train[:-1], param_set)  
        # loss_RK4 += loss_fn(target_train[1:],RK4_pred)    


    ###################################################################################            
    # for iteration in range(max_iterations):
    
    #     loss_RK4 = torch.autograd.Variable(torch.tensor([0.0], requires_grad=True)).to(device)
    #     loss_derivative = torch.autograd.Variable(torch.tensor([0.0], requires_grad=True)).to(device)
        
    #     optimizer2.zero_grad()
        
    #     for i in range(len(train_dataloader)):
    #         for batch_idx, train_sample in enumerate(train_dataloader[i]):
    #             "unpacking the train data"
    #             (data_train, target_train, prediction, LHS, fun_library) = train_sample

    #             #######################################

    #             """loading the data to GPU """

    #             data_train = data_train.float().to(device)
    #             target_train = target_train.float().to(device)
    #             prediction = prediction.float().to(device)
    #             LHS = LHS.float().to(device)
    #             fun_library = fun_library.float().to(device)
                
    #             #########################################
                
    #             RHS = network2(fun_library)
    #             loss_derivative += loss_fn(LHS,RHS)
                
                
    #             # RK4_pred = RK4( network2, target_train[:-1], param_set)  
    #             # loss_RK4 += loss_fn(target_train[1:],RK4_pred)
        
        ###########################################
        target_loss =  1.0 * loss_derivative 
        target_loss.backward()
        optimizer2.step()        

        loss_values.append(target_loss.item())   
        loss_values_derivative.append(loss_derivative.item())
        loss_values_RK4.append(loss_RK4.item())
        
   
        
        # ================ Logging ===========================
        
        """looging the results of training and printing on the screen """

        logger(
            iteration,
            loss_values,
            loss_values_derivative,
            loss_values_RK4,
            network2.final.weight,
            threshold_iterations,
            period_iteration)


        
        # if iteration > threshold_iterations and iteration % period_iteration == 0:
            
        #     """masking the coefficients and re-setting the optimizers """
        #     Wk = network2.final.weight.clone().detach()
        #     tl_value = threshold_value
        #     Mask_Wk = (Wk.abs() > tl_value).type(torch.float)
        #     network2.final.weight = torch.nn.Parameter( Wk * Mask_Wk )
        #     network2.final.weight.register_hook(
        #         lambda grad: grad.mul_(Mask_Wk)
        #     )
            
            
        #     #################################################################
            
            
        #     optimizer2 = torch.optim.Adam(
        #         [
        #             {
        #                 "params": network2.parameters(),
        #                 "lr": 1e-4 ,
        #                 "weight_decay": 0,
        #             },
        #         ]
        #     )
            



    return (
        loss_values,
        loss_values_derivative,
        loss_values_RK4,
        network2
    )



#######################################################################################
# Y = network1(data_train)
# prediction = Y.clone().detach().cpu()
# estimated_deri  = Numerical_Derivative(prediction,param_set).to(device)

# for iteration in range(burnin_iterations):
    
#     optimizer1.zero_grad()
#     loss = torch.autograd.Variable( torch.tensor([0.0], requires_grad=True)).to(device)
    
#     for i in range(len(train_dataloader)):
#         for batch_idx, train_sample in enumerate(train_dataloader[i]):
#             (data_train, target_train) = train_sample

#             #######################################

#             """loading the data to GPU """

#             data_train = data_train.float().to(device)
#             target_train = target_train.float().to(device)
            
#             #######################################
            
#             prediction =  network1(data_train)        
#             dot_Y = Derivative(network1, data_train, param_set)
            
#             loss1 = loss_fn(prediction,target_train)
#             loss2 = loss_fn(dot_Y,estimated_deri)
            
#             loss += 0.8* loss1 + 0.2 * loss2
    
    
    
#     loss.backward()
#     optimizer1.step()
    
#     loss_values_NN.append(loss.item())
#     ##########################################Loggering
    
#     burnin_logger(iteration,loss_values_NN,burnin_iterations)        


# Y = network1(data_train)
# dot_Y = Derivative(network1, data_train, param_set)
# poly_library = Library(Y , param_set)

# prediction = Y.clone().detach().cpu()  #复制，去梯度
# LHS = dot_Y.clone().detach().cpu() #复制，去梯度
# fun_library = poly_library.clone().detach().cpu()  #复制，去梯度

# ####################################################################################
# plt.style.use('seaborn-v0_8-whitegrid')

# plt.figure(figsize=(12, 6))

# for q in range(LHS.shape[1]):
#     plt.plot( LHS[:,q], label = 'x'+str(q+1))

# plt.title('Derivatives')
# plt.xlabel('$t$', fontsize=20)
# plt.ylabel('$x$', fontsize=20)

# plt.legend(fontsize=26)
# plt.show()
# ######################################################################  
# plt.style.use('seaborn-v0_8-whitegrid')

# plt.figure(figsize=(12, 6))

# for q in range(fun_library.shape[1]):
#     plt.plot( fun_library[:,q], label = 'x'+str(q+1))

# plt.title('Library')
# plt.xlabel('$t$', fontsize=20)
# plt.ylabel('$x$', fontsize=20)

# plt.legend(fontsize=26)
# plt.show()

# torch.save(prediction, 'matrix/prediction.pth')
# torch.save(LHS, 'matrix/LHS.pth')
# torch.save(fun_library, 'matrix/fun_library.pth')
# #################################################################################
# network2 = NNReLu( 10, [300,300,300,300,300,300], int(param_set.num_indp_var) ).to(device)

# optimizer2 = torch.optim.Adam(
#     [
#         {
#             "params": network2.parameters(),
#             "lr": 7e-6,
#             "weight_decay": 0,
#         }
#     ]
# )


# fun_library = fun_library.to(device)
# LHS = LHS.to(device)

# loss_fn = nn.MSELoss()
# epoch1 = 100000

# for i in range(epoch1):
#     target1 = network2(fun_library)
    
#     loss1 = loss_fn(target1,LHS)
    
#     loss1.backward()
#     optimizer2.step()
#     optimizer2.zero_grad()
    
#     print(loss1.item())


################################################################################
        #####################################################